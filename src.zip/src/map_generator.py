import xml.etree.ElementTree as et
import numpy as np
import sys
np.set_printoptions(threshold=sys.maxsize)

def get_row_compressor(old_dimension, new_dimension):
    dim_compressor = np.zeros((new_dimension, old_dimension))
    bin_size = float(old_dimension) / new_dimension
    next_bin_break = bin_size
    which_row = 0
    which_column = 0
    while which_row < dim_compressor.shape[0] and which_column < dim_compressor.shape[1]:
        if round(next_bin_break - which_column, 10) >= 1:
            dim_compressor[which_row, which_column] = 1
            which_column += 1
        elif next_bin_break == which_column:

            which_row += 1
            next_bin_break += bin_size
        else:
            partial_credit = next_bin_break - which_column
            dim_compressor[which_row, which_column] = partial_credit
            which_row += 1
            dim_compressor[which_row, which_column] = 1 - partial_credit
            which_column += 1
            next_bin_break += bin_size
    dim_compressor /= bin_size
    return dim_compressor

def get_column_compressor(old_dimension, new_dimension):
    return get_row_compressor(old_dimension, new_dimension).transpose()

def compress_and_average(array, new_shape):
    # Note: new shape should be smaller in both dimensions than old shape
    return np.mat(get_row_compressor(array.shape[0], new_shape[0])) * \
           np.mat(array) * \
           np.mat(get_column_compressor(array.shape[1], new_shape[1]))

treemap = et.parse("../misc/map_example.xml")
treeroot = treemap.getroot()
# maparray = 
i = 0
j = 0
for data in treeroot[0]:
    print(data.attrib)
    width = data.attrib['width']
    print("width: ", int(width))
    height = data.attrib['height']
    print("height: ", int(height))
#initialize map array with width and height
maparray = np.zeros((int(width), int(height)))    
for data in treeroot[0].findall('grid'):
    #for each row in the map, fill the values in the map array with the values from the xml file
    for tile in data.findall('row'):
        for char in tile.text.split(' '):
            # print(char)
            if((i < int(width)) and (j < int(height))):
                #print i, j            
                maparray[i][j] = int(char)
                # print(i, j, maparray[i][j])
                j += 1
        i += 1
        j = 0
   
print(maparray)
rosmap = bin_ndarray(maparray, (int(width)*4, int(height)*4), operation='mean')
print(rosmap)

# for x in treeroot[0][0]:
#     for y in x.text.split():
#print the map array in a 2D format